/* Style Shop items: purely visual themes for the interface and the player's website.
   Nothing here touches the economy. Items unlock through lifetime milestones (stats that
   survive era resets), so customizing never costs progress.

   Every operating system (Z.OSES) has its own catalogue. ChaosOS 7 Aero is the first;
   ChaosOS 8 Metro starts from scratch, and its milestones count from the moment it was
   installed (Z.opsys.since).

   Each item: id, name, desc, swatch (CSS background for the preview tile) and
   req: null (free) or { text, have(s), need }. Ids are unique per category across all
   catalogues. The CSS lives in css/game.css (Aero in section 5, Metro in section 8),
   keyed by body[data-bg|data-color|data-site-style|data-fx="<id>"]. */
(function (Z) {
  'use strict';

  const st = (key) => s => s.stats[key] || 0;
  const achievements = s => Object.keys(s.achievements).length;
  const R = (text, have, need) => ({ text, have, need });
  // A ChaosOS 8 milestone: counts only what happened after the upgrade.
  const on8 = (key, scale) => s => s.os && s.os.id === 'metro' ? Z.opsys.since(s, key) / (scale || 1) : 0;

  const AERO = [
    {
      id: 'bg', name: 'Backgrounds', icon: '🏞️', blurb: 'The world behind the glass.',
      items: [
        { id: 'sky', name: 'Clear Sky', desc: 'Blue sky, soft clouds, a green hill. The classic.', req: null,
          swatch: 'radial-gradient(ellipse 60% 30% at 85% 10%, #fffbe0, transparent 70%), radial-gradient(ellipse 90% 35% at 30% 110%, #4cbc3e 0 50%, transparent 70%), linear-gradient(#1f7fd0, #a9def8 60%, #5bc1e8)' },
        { id: 'hills', name: 'Rolling Hills', desc: 'A deep blue sky over one impossibly green hill.',
          req: R('Click 1,000 times in total', st('totalClicks'), 1000),
          swatch: 'radial-gradient(ellipse 120% 55% at 30% 118%, #6fd14a 0 52%, #3f9a28 60%, transparent 61%), radial-gradient(ellipse 30% 10% at 70% 25%, #fff, transparent 70%), linear-gradient(#1557c9, #5aa8f0 55%, #d6eefc)' },
        { id: 'ocean', name: 'Deep Lagoon', desc: 'Sunbeams falling through clear turquoise water.',
          req: R('Earn 100M Attention in total', st('totalAttention'), 1e8),
          swatch: 'conic-gradient(from 160deg at 50% -20%, transparent 0deg, rgba(255,255,255,.3) 8deg, transparent 16deg, rgba(255,255,255,.2) 26deg, transparent 34deg), linear-gradient(#7fe3f0, #1b9bc2 35%, #0b5f8f 70%, #062f55)' },
        { id: 'sunset', name: 'Sunset Bloom', desc: 'A warm evening glow in pink, peach and violet.',
          req: R('Unlock 15 achievements', achievements, 15),
          swatch: 'radial-gradient(circle at 50% 66%, #fff4c2 0 8%, rgba(255,200,120,.6) 16%, transparent 40%), linear-gradient(#2b1d5c, #8a3a8f 32%, #f06a6a 55%, #ffb35c 66%, #c45a8a 80%, #4a2466)' },
        { id: 'aurora', name: 'Aurora Night', desc: 'Northern lights over a quiet, starry night.',
          req: R('Reach the Social Media Era', st('eras'), 1),
          swatch: 'radial-gradient(ellipse 80% 20% at 40% 35%, rgba(80,255,170,.65), transparent 70%), radial-gradient(ellipse 60% 16% at 70% 25%, rgba(170,110,255,.55), transparent 70%), linear-gradient(#030b26, #0b1f4a 60%, #123a5c)' },
        { id: 'frost', name: 'Crystal Frost', desc: 'Bright, icy and pale, like a frozen window.',
          req: R('Buy 200 buildings in total', st('buildingsBought'), 200),
          swatch: 'radial-gradient(circle at 30% 30%, #fff 0 12%, transparent 40%), linear-gradient(135deg, #e6f7ff, #b5e6fb 45%, #ffffff 60%, #a9dcf2)' },
      ],
    },
    {
      id: 'color', name: 'Colors', icon: '🎨', blurb: 'The tint of the glass, buttons and title bars.',
      items: [
        { id: 'aqua', name: 'Aqua Blue', desc: 'Glossy sky blue. Where it all started.', req: null,
          swatch: 'linear-gradient(rgba(255,255,255,.55), rgba(255,255,255,.1) 48%, transparent 52%), linear-gradient(#45b3f5, #0d63c4)' },
        { id: 'mint', name: 'Mint Glass', desc: 'Fresh green and teal, like a cold soda.',
          req: R('Buy 75 buildings in total', st('buildingsBought'), 75),
          swatch: 'linear-gradient(rgba(255,255,255,.55), rgba(255,255,255,.1) 48%, transparent 52%), linear-gradient(#4fe0b0, #0f8a64)' },
        { id: 'orchid', name: 'Orchid', desc: 'Violet glass with a magenta glow.',
          req: R('Reach 75% Chaos', st('highestChaos'), 75),
          swatch: 'linear-gradient(rgba(255,255,255,.55), rgba(255,255,255,.1) 48%, transparent 52%), linear-gradient(#c58cff, #6a2bc4)' },
        { id: 'amber', name: 'Sunlit Amber', desc: 'Honey and orange, warm as afternoon light.',
          req: R('Earn $10M in total', st('totalMoney'), 1e7),
          swatch: 'linear-gradient(rgba(255,255,255,.55), rgba(255,255,255,.1) 48%, transparent 52%), linear-gradient(#ffc04d, #d9700b)' },
        { id: 'graphite', name: 'Graphite Ultimate', desc: 'Black smoked glass with silver edges.',
          req: R('Survive a meltdown', st('meltdowns'), 1),
          swatch: 'linear-gradient(rgba(255,255,255,.4), rgba(255,255,255,.06) 48%, transparent 52%), linear-gradient(#5a616c, #0c0e12)' },
        { id: 'rose', name: 'Bubblegum', desc: 'Pink candy gloss. Unapologetically shiny.',
          req: R('Unlock 25 achievements', achievements, 25),
          swatch: 'linear-gradient(rgba(255,255,255,.55), rgba(255,255,255,.1) 48%, transparent 52%), linear-gradient(#ff8cc8, #d12f86)' },
      ],
    },
    {
      id: 'site', name: 'Website Styles', icon: '🖥️', blurb: 'How your own website looks to visitors.',
      items: [
        { id: 'era', name: 'Follows the Era', desc: 'Your site changes style with every Internet Era.', req: null,
          swatch: 'linear-gradient(135deg, #fffff4 0 25%, #f5f6f8 25% 50%, #231036 50% 75%, #0b0f14 75%)' },
        { id: 'aero', name: 'Aero Clean', desc: 'White, airy and blue, whatever the era.', req: null,
          swatch: 'linear-gradient(#ffffff, #e2f1fd)' },
        { id: 'web2', name: 'Web 2.0 Beta', desc: 'Huge rounded type, gradients and a permanent beta badge.',
          req: R('Buy 20 upgrades in total', st('upgradesBought'), 20),
          swatch: 'linear-gradient(#ffffff 0 55%, #eaf6d9 55%), radial-gradient(circle at 70% 30%, #ff9a2e 0 18%, transparent 20%)' },
        { id: 'retro', name: 'GeoCities ’98', desc: 'Comic Sans, Times New Roman and pure enthusiasm.',
          req: R('Click 2,500 times in total', st('totalClicks'), 2500),
          swatch: 'repeating-linear-gradient(45deg, #fffff4 0 8px, #fff6c8 8px 16px)' },
        { id: 'midnight', name: 'Midnight Glass', desc: 'A dark site with neon-cyan glow.',
          req: R('Play for 60 minutes', s => (s.stats.playTime || 0) / 60, 60),
          swatch: 'radial-gradient(circle at 50% 30%, rgba(111,211,255,.5), transparent 55%), linear-gradient(#0d1b2e, #050b14)' },
        { id: 'news', name: 'Daily Newsprint', desc: 'Serious serif headlines for unserious news.',
          req: R('Experience 30 internet events', st('events'), 30),
          swatch: 'repeating-linear-gradient(#f4efe1 0 6px, #e4dcc6 6px 7px)' },
      ],
    },
    {
      id: 'fx', name: 'Effects', icon: '✨', blurb: 'Extra light and motion floating over the background.',
      items: [
        { id: 'bubbles', name: 'Glass Bubbles', desc: 'A few still bubbles and soft light streaks.', req: null,
          swatch: 'radial-gradient(circle at 30% 60%, transparent 0 9px, rgba(255,255,255,.9) 10px, transparent 12px), radial-gradient(circle at 70% 35%, transparent 0 6px, rgba(255,255,255,.9) 7px, transparent 9px), linear-gradient(#3f9ae0, #8fd2f5)' },
        { id: 'calm', name: 'Calm', desc: 'No effects. Just the background.', req: null,
          swatch: 'linear-gradient(#5aa8e6, #9fd8f5)' },
        { id: 'float', name: 'Rising Bubbles', desc: 'Bubbles drifting slowly upward.',
          req: R('Earn 1M Attention in total', st('totalAttention'), 1e6),
          swatch: 'radial-gradient(circle at 25% 75%, transparent 0 7px, #fff 8px, transparent 10px), radial-gradient(circle at 60% 45%, transparent 0 10px, #fff 11px, transparent 13px), radial-gradient(circle at 80% 15%, transparent 0 4px, #fff 5px, transparent 7px), linear-gradient(#1b9bc2, #7fe3f0)' },
        { id: 'sparkle', name: 'Sparkles', desc: 'Tiny glints that twinkle across the screen.',
          req: R('Unlock 10 achievements', achievements, 10),
          swatch: 'radial-gradient(circle at 20% 30%, #fff 0 2px, transparent 4px), radial-gradient(circle at 70% 60%, #fff 0 2px, transparent 4px), radial-gradient(circle at 45% 80%, #fff 0 1.5px, transparent 3px), linear-gradient(#2a5bd0, #8fd2f5)' },
        { id: 'rays', name: 'Light Rays', desc: 'Slowly turning sunbeams from the corner of the sky.',
          req: R('Use 15 Actions', st('actions'), 15),
          swatch: 'repeating-conic-gradient(from 0deg at 0 0, rgba(255,255,255,.55) 0 5deg, transparent 5deg 14deg), linear-gradient(#3f9ae0, #b9e6fa)' },
        { id: 'flare', name: 'Lens Flare', desc: 'Glowing orbs trailing from the sun.',
          req: R('Earn 1T Attention in total', st('totalAttention'), 1e12),
          swatch: 'radial-gradient(circle at 80% 20%, #fff 0 8%, transparent 20%), radial-gradient(circle at 55% 45%, rgba(140,255,200,.7) 0 7%, transparent 9%), radial-gradient(circle at 35% 65%, rgba(255,170,240,.6) 0 10%, transparent 12%), linear-gradient(#1f7fd0, #a9def8)' },
      ],
    },
  ];

  /* ChaosOS 8 Metro: flat color, square tiles, light type. */
  const tile = c => 'linear-gradient(135deg, ' + c + ' 0 62%, rgba(0, 0, 0, .18) 62%), linear-gradient(' + c + ', ' + c + ')';
  const METRO = [
    {
      id: 'bg', name: 'Backgrounds', icon: '🏞️', blurb: 'The Start screen behind your tiles.',
      items: [
        { id: 'light', name: 'Blue Light', desc: 'Deep blue with soft beams of light. The ChaosOS 8 classic.', req: null,
          swatch: 'repeating-conic-gradient(from 205deg at 22% 125%, rgba(255,255,255,.16) 0 4deg, transparent 4deg 12deg), linear-gradient(160deg, #0b2f7c, #1561d6 55%, #0a3a94)' },
        { id: 'royal', name: 'Royal Purple', desc: 'The famous purple Start screen, with big quiet circles.',
          req: R('Reach the next Internet Era on ChaosOS 8', on8('eras'), 1),
          swatch: 'radial-gradient(circle at 78% 28%, rgba(255,255,255,.12) 0 24%, transparent 25%), radial-gradient(circle at 18% 86%, rgba(255,255,255,.08) 0 34%, transparent 35%), linear-gradient(#3d1c74, #261052)' },
        { id: 'emerald', name: 'Emerald Grid', desc: 'Green as a fresh install, with a faint tile grid.',
          req: R('Earn 1Qa Attention on ChaosOS 8', on8('totalAttention'), 1e15),
          swatch: 'linear-gradient(rgba(255,255,255,.13) 2px, transparent 2px) 0 0 / 18px 18px, linear-gradient(90deg, rgba(255,255,255,.13) 2px, transparent 2px) 0 0 / 18px 18px, linear-gradient(#11893f, #0a5a2a)' },
        { id: 'carbon', name: 'Carbon Lines', desc: 'Dark graphite with fine diagonal pinstripes.',
          req: R('Survive a meltdown on ChaosOS 8', on8('meltdowns'), 1),
          swatch: 'repeating-linear-gradient(135deg, rgba(255,255,255,.08) 0 2px, transparent 2px 9px), linear-gradient(#2c3038, #15171b)' },
        { id: 'ribbon', name: 'Sunset Ribbon', desc: 'Orange and magenta ribbons on deep red.',
          req: R('Reach 2 more Internet Eras on ChaosOS 8', on8('eras'), 2),
          swatch: 'radial-gradient(130% 60% at 0% 104%, #ff8a00 0 42%, transparent 43%), radial-gradient(120% 70% at 104% 0%, #e91e63 0 36%, transparent 37%), linear-gradient(135deg, #7a0f3a, #b3123e)' },
        { id: 'teal', name: 'Teal Waves', desc: 'Calm flat waves rolling in from the bottom.',
          req: R('Earn 1Qi Attention on ChaosOS 8', on8('totalAttention'), 1e18),
          swatch: 'radial-gradient(140% 50% at 30% 136%, #19e0cb 0 50%, transparent 51%), radial-gradient(140% 50% at 70% 122%, #00b5aa 0 46%, transparent 47%), linear-gradient(#00566e, #00808f)' },
      ],
    },
    {
      id: 'color', name: 'Colors', icon: '🎨', blurb: 'The accent color of buttons, tabs and highlights.',
      items: [
        { id: 'cobalt', name: 'Cobalt', desc: 'Strong, clean blue. Where ChaosOS 8 starts.', req: null, swatch: tile('#1f6fd8') },
        { id: 'lime', name: 'Lime', desc: 'A bright, cheerful green.',
          req: R('Click 300 times on ChaosOS 8', on8('totalClicks'), 300), swatch: tile('#7fb51f') },
        { id: 'orange', name: 'Orange', desc: 'Loud, warm and impossible to miss.',
          req: R('Buy 40 upgrades on ChaosOS 8', on8('upgradesBought'), 40), swatch: tile('#f26b0f') },
        { id: 'magenta', name: 'Magenta', desc: 'Hot pink with a lot of confidence.',
          req: R('Buy 500 buildings on ChaosOS 8', on8('buildingsBought'), 500), swatch: tile('#d6006f') },
        { id: 'crimson', name: 'Crimson', desc: 'Deep red, for serious internet business.',
          req: R('Earn $1Qi on ChaosOS 8', on8('totalMoney'), 1e18), swatch: tile('#c8102e') },
        { id: 'violet', name: 'Violet', desc: 'Electric purple, straight from a phone ad.',
          req: R('Play for 2 hours on ChaosOS 8', on8('playTime', 60), 120), swatch: tile('#8a2be2') },
      ],
    },
    {
      id: 'site', name: 'Website Styles', icon: '🖥️', blurb: 'How your own website looks to visitors.',
      items: [
        { id: 'modern', name: 'Modern UI', desc: 'A white page with a big photo header and light, clean type.', req: null,
          swatch: 'linear-gradient(180deg, transparent 0 56%, #ffffff 56%), radial-gradient(ellipse 90% 32% at 50% 60%, #5fbf3a 0 60%, transparent 61%), linear-gradient(#3f97ec, #c3e5ff)' },
        { id: 'follow', name: 'Follows the Era', desc: 'Your site changes style with every Internet Era.', req: null,
          swatch: 'linear-gradient(135deg, #ffffff 0 25%, #f5f6f8 25% 50%, #231036 50% 75%, #0b0f14 75%)' },
        { id: 'dark', name: 'Dark Theme', desc: 'Black page, white type, one accent line.',
          req: R('Play for 30 minutes on ChaosOS 8', on8('playTime', 60), 30),
          swatch: 'linear-gradient(90deg, #1f6fd8 0 100%) 50% 66% / 60% 4px no-repeat, linear-gradient(#101010, #1d1d1d)' },
        { id: 'livetiles', name: 'Live Tiles', desc: 'Your homepage turns into a wall of colorful tiles.',
          req: R('Use 20 Actions on ChaosOS 8', on8('actions'), 20),
          swatch: 'conic-gradient(#1f6fd8 0 25%, #e51400 0 50%, #7fb51f 0 75%, #f26b0f 0) 0 0 / 50% 50%' },
        { id: 'headline', name: 'Headline News', desc: 'A bold red news app header over clean columns.',
          req: R('Experience 40 internet events on ChaosOS 8', on8('events'), 40),
          swatch: 'linear-gradient(180deg, #c8102e 0 42%, transparent 42%), repeating-linear-gradient(180deg, #ffffff 0 6px, #e4e4e4 6px 7px)' },
        { id: 'panorama', name: 'Panorama', desc: 'A huge, thin title that runs off the edge of the page.',
          req: R('Click 2,000 times on ChaosOS 8', on8('totalClicks'), 2000),
          swatch: 'linear-gradient(transparent 0 26%, rgba(20, 60, 120, .2) 26% 54%, transparent 54%), linear-gradient(120deg, #e3ebf5, #ffffff)' },
      ],
    },
    {
      id: 'fx', name: 'Effects', icon: '✨', blurb: 'Motion behind the tiles.',
      items: [
        { id: 'drift', name: 'Drifting Tiles', desc: 'A few see-through squares slowly floating by.', req: null,
          swatch: 'linear-gradient(rgba(255,255,255,.35), rgba(255,255,255,.35)) 22% 28% / 12px 12px no-repeat, linear-gradient(rgba(255,255,255,.22), rgba(255,255,255,.22)) 72% 58% / 18px 18px no-repeat, linear-gradient(rgba(255,255,255,.3), rgba(255,255,255,.3)) 42% 82% / 8px 8px no-repeat, linear-gradient(#0d3f9e, #1a63d0)' },
        { id: 'still', name: 'Still', desc: 'No effects. Just the background.', req: null,
          swatch: 'linear-gradient(#0f4bb0, #1a63d0)' },
        { id: 'dots', name: 'Loading Dots', desc: 'Five little dots racing across the top of the screen.',
          req: R('Catch 3 floating notifications on ChaosOS 8', on8('bonuses'), 3),
          swatch: 'radial-gradient(circle, #fff 0 2.5px, transparent 3px) 26% 50% / 10px 10px no-repeat, radial-gradient(circle, #fff 0 2.5px, transparent 3px) 38% 50% / 10px 10px no-repeat, radial-gradient(circle, #fff 0 2.5px, transparent 3px) 50% 50% / 10px 10px no-repeat, radial-gradient(circle, #fff 0 2.5px, transparent 3px) 62% 50% / 10px 10px no-repeat, radial-gradient(circle, #fff 0 2.5px, transparent 3px) 74% 50% / 10px 10px no-repeat, linear-gradient(#0d3f9e, #1a63d0)' },
        { id: 'pixels', name: 'Pixel Rain', desc: 'Tiny square pixels falling like snow.',
          req: R('Click 1,000 times on ChaosOS 8', on8('totalClicks'), 1000),
          swatch: 'linear-gradient(#fff, #fff) 20% 18% / 4px 4px no-repeat, linear-gradient(#fff, #fff) 64% 34% / 3px 3px no-repeat, linear-gradient(#fff, #fff) 38% 62% / 4px 4px no-repeat, linear-gradient(#fff, #fff) 80% 78% / 3px 3px no-repeat, linear-gradient(#fff, #fff) 14% 84% / 3px 3px no-repeat, linear-gradient(#0d3f9e, #1a63d0)' },
        { id: 'beams', name: 'Light Sweep', desc: 'Wide beams of light slowly sweeping the sky.',
          req: R('Earn 100 Clout on ChaosOS 8', on8('cloutEarned'), 100),
          swatch: 'repeating-conic-gradient(from 200deg at 20% 120%, rgba(255,255,255,.24) 0 5deg, transparent 5deg 14deg), linear-gradient(#0b2f7c, #1561d6)' },
        { id: 'glow', name: 'Accent Glow', desc: 'A soft glow in your accent color, breathing at the bottom.',
          req: R('Catch 10 floating notifications on ChaosOS 8', on8('bonuses'), 10),
          swatch: 'radial-gradient(ellipse 80% 42% at 50% 100%, rgba(80, 170, 255, .85), transparent 70%), linear-gradient(#0a2a6e, #0d3f9e)' },
      ],
    },
  ];

  const SETS = { aero: AERO, metro: METRO };
  const DEFAULTS = {
    aero: { bg: 'sky', color: 'aqua', site: 'era', fx: 'bubbles' },
    metro: { bg: 'light', color: 'cobalt', site: 'modern', fx: 'drift' },
  };

  const ITEM = Object.create(null);
  for (const os in SETS) {
    for (const cat of SETS[os]) {
      for (const item of cat.items) ITEM[cat.id + ':' + item.id] = Object.assign({ cat: cat.id, os }, item);
    }
  }

  /** The catalogue for an OS id; unknown ids get the first one. */
  function setFor(osId) { return SETS[osId] || AERO; }

  Z.COSMETICS = {
    SETS,
    CATEGORIES: AERO,              // the ChaosOS 7 catalogue (tools use it as the default)
    CAT: Z.util.byId(AERO),
    ITEM,
    DEFAULTS,
    setFor,
    defaultsFor: osId => DEFAULTS[osId] || DEFAULTS.aero,
    key: (cat, id) => cat + ':' + id,
  };
})(window.ICHAOS = window.ICHAOS || {});
